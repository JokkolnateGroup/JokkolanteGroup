<?php

session_start();

include('../html/config/base.php');

if (isset($_POST['valider'])) {
  $erreur = "";
  if (!empty($_POST['pseudo']) and !empty($_POST['mdp'])) {
    //htmlspecialchars c'est pour eviter que l'utilisateur entre du code html
    $pseudo_saisi = htmlspecialchars($_POST['pseudo']);
    $mdp_saisi = htmlspecialchars($_POST['mdp']);

    $sql = $conn->query("SELECT * FROM admin");
    $true =  false;
    while ($user = $sql->fetch()) {
      if ($pseudo_saisi == $user['pseudo'] and md5($mdp_saisi) == $user['mdp']) {
        $true = true;
      }
    }
    if ($true) {
      $_SESSION['pseudo'] = $pseudo_saisi;
      header('Location: chargement.php');
    } else {
      $erreur = "Cet utilisateur n'existe pas.";
    }
  } else {
    $erreur = "Veuillez compléter tous les champs...";
  }
}
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Connexion </title>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="../publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../publics/css/login.css">

</head>

<body>




  <div class="container" id="container">

    <a class="navbar-brand m-3" href="index.php"><img src="../publics/images/Group571.png" width="250" alt=""></a>

    <form class="form" method="POST" style="width:350px; ">

      <h4 class="texte text-primary text-center py-2" style=" font-family: 'Ubuntu';font-style: normal;font-weight: 400;font-size: 22px;line-height: 34px;align-items: center;text-align: center;color: #009EE2;">
        Welcome to <span style="font-family: 'Ubuntu';font-style: normal;font-weight: 700;font-size: 22px;line-height: 34px;align-items: center;text-align: center;letter-spacing: -0.02em;color: #009EE2;"> JokkolanteGroup.com</span>
      </h4>
      <div class="bg-primary  text-center ">
        <h5 class="text-white py-2">
          Log in with an account below :
        </h5>

        <div class="three">
          <a class="text-reset" href="">
            <img src="../publics/images/inst.png" width="25px" height="25px" alt="" />
          </a>
          <a class="text-reset" href="https://www.facebook.com/Jokkolantegroup?mibextid=LQQJ4d">
            <img src="../publics/images/face.png" width="25px" height="25px" alt="" />
          </a>

          <a class="text-reset" href="https://twitter.com/jokkolante?t=gE7J4WZzU6kc2MukiG2_zw&s=09">
            <img src="../publics/images/tiw.png" width="25px" height="25px" alt="" />
          </a>
          <a class="text-reset" href="https://www.linkedin.com/company/jokkolante">
            <img src="../publics/images/link.png" width="25px" height="25px" alt="" />
          </a>

        </div>
      </div>
      <h5 class="text text-primary py-2 text-center">
        Or log in with a password :
      </h5>
      <div class="imp">
        <label style="font-family: 'Ubuntu';font-style: normal;font-size: 15px;letter-spacing: -0.02em;color: #009EE2;margin-top:10px;">Your e-mail address or username</label>
        <input type="text" name="pseudo" class="form-control   w-75">

        <label style="font-family: 'Ubuntu';font-style: normal;font-size: 15px;letter-spacing: -0.02em;color: #009EE2;">Your password</label>
        <input type="password" name="mdp" class="form-control   w-75">
        <div class="form-check ">
          <input type="checkbox" class="form-check-input  ">
          <label style="font-family: 'Ubuntu';font-style: normal;font-size: 15px;letter-spacing: -0.02em;color: #009EE2;">Remembering me</label>
        </div>
      </div>
      <span id="error" style="color: red; text-align:center;">
        <?php
        if (isset($erreur)) {
          echo $erreur;
        }
        ?>
      </span>
      <input type="submit" id='submit' name="valider" value='Se connecter'>

    </form>

    <div class="container">

      <p class=" text-center text-dark">
        Not a member yet? <a href="userSignUp" class=" text-dark ">Click here to apply to be an admin</a> <br>
        <a style="color: #009EE2;" href="#"> Forgot your password ? </a>
      </p>
      <div class="row modif" style="background-image: url(../publics/images/Group352.jpg); background-size: contain;background-repeat: no-repeat;">

      </div>
    </div>
  </div>


  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src='https://code.jquery.com/jquery-1.12.0.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../publics/js/main.js"></script>
  <script src="../publics/js/main1.js"></script>
  <script src="../publics/js/menu.js"></script>
  <script src="../publics/js/login.js"></script>
</body>

</html>