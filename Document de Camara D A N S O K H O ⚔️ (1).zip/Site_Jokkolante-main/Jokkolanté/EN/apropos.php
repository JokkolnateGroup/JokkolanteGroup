<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title> About us</title>

    <link rel="icon" type="image/x-icon" href="../publics/images/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="http://daneden.me/animate">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

    <link href="../publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
    <link rel="stylesheet" href="../publics/css/header.css">
    <link rel="stylesheet" href="../publics/css/footer.css">
    <link rel="stylesheet" href="../publics/css/apropos.css">
    <link rel="stylesheet" href="../publics/css/experts.css">
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>
</head>

<body>

    <?php
    include('header.php')
    ?>
    <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
        <h1 class="post-img animate__animated animate__fadeInDown" id="words"></h1>
    </section>

    <section class="hero-apropos1">
        <div class="container-fluid app">
            <div class="row justify-content-center gy-3" data-aos="zoom-in" data-aos-delay="100">
                <div class="col-md-6 mb-4">
                    <article class="block-wrap1">
                        <div class="col-12 ">
                            <div class="block-propos">
                                <img src="../publics/images/localisation.png" alt="">
                                <div class="card-body">
                                    <p>Our agency is a strategic partner for companies looking to boost their visibility and engagement with their target audience.</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-6 mb-4">
                    <article class="block-wrap1">
                        <div class="col-12 ">
                            <div class="block-propos1">
                                <div class="card-body">
                                    <p>We're passionate about creating innovative and effective campaigns that set our clients apart from the competition.We're passionate about creating innovative and effective campaigns that set our clients apart from the competition.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 ">
                            <div class="block-propos1">
                                <div class="card-body">
                                    <div class="service-bouton">
                                        <a href="html/Services/service.php"><img src="../publics/images/edit.png" alt="">OUR SERVICES</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>

            </div>
        </div>
    </section>
    <div class="container">

        <p class="textes animate__animated animate__fadeInDown" style="margin-top:50px;" data-aos="fade-down" data-aos-delay="100">
        Why entrust your creative projects to us? </p>

        <div class="row row-cols-1 row-cols-md-3 g-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>01</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">A team</h5>

                        <p class="card-text">100% Available</p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>02</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">A physical office</h5>

                        <p class="card-text">To guarantee proximity</p>
                    </div>

                </div>
            </div>
            <div class="col">

                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>03</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Quality/Price ratio</h5>

                        <p class="card-text">Unbeatable</p>
                    </div>

                </div>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-3 g-4 bloc2" data-aos="zoom-in" data-aos-delay="100">
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>04</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Our creativity</h5>

                        <p class="card-text">Serving your projects</p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>05</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">A graphics studio</h5>

                        <p class="card-text">Designed for all your projects</p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body numero">
                        <p>06</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Guaranteed budget</h5>

                        <p class="card-text">Respected and optimised</p>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <section oncontextmenu='return false' class="snippet-body align-items-center justify-content-center">

        <div class="container">
            <div class="row">
                <div class="col-md-1à mb-4">
                    <article class="block-wrap1">
                        <div class="col-12">
                            <div class="block-propos" data-aos="fade-down" data-aos-delay="100">
                                <div class="card-body">

                                    <p class="title-section-qsn-vc"><span class="trait-title-section-qsn-vc">
                                            ex</span>perts</span> at your service</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-12">
                    <div id="news-slider" class="owl-carousel ">
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/fa.svg" alt="">

                                <div class="over-layer">
                                    <img src="../publics/images/fa1.svg" alt="">
                                    <!-- <div class="row">
                                <a href="https://twitter.com/FatouMb75134996/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/fatou-mbengue-326350220/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/profile.php?id=100052115983943/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/mbengue9250/?next=%2F/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> MBENGUE </a>
                                </h3>
                                <p class="post-description">Dynamics</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/dans.svg" alt="">
                                <div class="over-layer">
                                    <img src="../publics/images/dans1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="https://twitter.com/DANSOKHO15/status/1477018298327916545/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/mamadou-camara-dansokho/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/mamadou.dansokho.73/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/camaradansokho/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> DANSOKHO </a>
                                </h3>
                                <p class="post-description">The Optimist</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/ous.svg" alt="">
                                <div class="over-layer">
                                    <img src="../publics/images/ous1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="https://twitter.com/aw_ousseynou/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/ousseynou-aw-2764b3b1/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/ousseynou.awlemahatma/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/ousseynou_aw_le_mahatma/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">AW </a>
                                </h3>
                                <p class="post-description">The Visionary</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/ch.svg" alt="">
                                <div class="over-layer">
                                    <img src="../publics/images/ch1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/birahim-chim%C3%A8re-diaw/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/birahimchimere/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIAW</a>
                                </h3>
                                <p class="post-description">The Original</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/anta.svg" alt="">
                                <div class="over-layer">
                                    <img src="../publics/images/anta1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> AW </a>
                                </h3>
                                <p class="post-description">The Queen</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="../publics/images/sey.svg" alt="">
                                <div class="over-layer">
                                    <img src="../publics/images/sey1.svg" alt="">
                                    <!-- <div class="row">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIOUF </a>
                                </h3>
                                <p class="post-description">Zen</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
    </section>

    <?php

    include('footer.php');

    ?>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="../publics/js/active.js"></script>
    
    <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>
    <script type='text/javascript'>
        $(document).ready(function() {
            $("#news-slider").owlCarousel({
                items: 5,
                itemsDesktop: [1199, 5],
                itemsDesktopSmall: [980, 3],
                itemsMobile: [600, 2],
                navigation: true,
                navigationText: ["", ""],
                pagination: true,
                autoPlay: true,
                interval: 200,
                cycle: true
            });

        });
    </script>

    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script src="../publics/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="../publics/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="../publics/js/main.js"></script>
    <script src="../publics/js/main1.js"></script>
    <script src="../publics/js/menu.js"></script>
    <script>
        var
            pros = ['About Us'],
            part,
            i = 0,
            offset = 0,
            len = words.length,
            forwards = true,
            skip_count = 0,
            skip_delay = 5,
            speed = 200;

        var wordflick = function(idH1, tab) {
            setInterval(function() {
                if (forwards) {
                    if (offset >= tab[i].length) {
                        ++skip_count;
                        if (skip_count == skip_delay) {
                            forwards = false;
                            skip_count = 0;
                        }
                    }
                } else {
                    if (offset == 0) {
                        forwards = true;
                        i++;
                        offset = 0;
                        if (i >= len) {
                            i = 0;
                        }
                    }
                }
                part = tab[i].substr(0, offset);
                if (skip_count == 0) {
                    if (forwards) {
                        offset++;
                    }
                    // else {
                    //   offset--;
                    // }
                }
                $(idH1).text(part);
            }, speed);
        };

        $(document).ready(function() {
            wordflick('#words', pros);
        });
    </script>
</body>

</html>