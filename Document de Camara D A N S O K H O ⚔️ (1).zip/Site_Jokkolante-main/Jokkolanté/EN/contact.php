<?php

include('../html/config/base.php');

if (isset($_POST['valider'])) {
  $erreur = "";
  $succes = "";
  if (
    !empty($_POST['nom']) && !empty($_POST['email']) && !empty($_POST['sujet']) && !empty($_POST['message'])
  ) {
    //Enregistrement à la base de données
    $sql = "INSERT INTO contact (nom, email, sujet, message) VALUES (:nom, :email, :sujet, :message)";
    $res = $conn->prepare($sql);
    $insert_contact = $res->execute(array(":nom" => $_POST['nom'], ":email" => $_POST['email'], ":sujet" => $_POST['sujet'], ":message" => $_POST['message']));
    // vérifier si la requête d'insertion a réussi
    if ($insert_contact) {


      //Envoie de mail
      // $from =  $_POST['email'];
      // $to = "dramembasa2000@gmail.com";
      // $sujet = $_POST['sujet'];
      // $message = "Prénom : " .$_POST['prenom']."\r\nNom : " .$_POST['nom']."\r\nEmail : " .$_POST['email']."\r\nTéléphone : " .$_POST['tel']."\r\nBudget : " .$_POST['budget']."\r\nDelai : " .$_POST['delai']."\r\nDomaine d'activité : " .$_POST['domaine']."\r\n";
      // $message .=  "Message : ".$_POST['message'];
      // $headers = "Content-Type: text/plain; charset=utf-8\r\nDe: " .$from;
      // // $headers .= "Reply To: " .$from."\r\n";

      // if (mail($to, $sujet, $message, $headers)) {
      $succes = "The message has been sent successfully.";
      // } else {
      //     $erreur = "Erreur survenu";
      // }

    }
  } else {
    $erreur = "All fields must be completed.";
  }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title> Contact </title>

  <link rel="icon" type="image/x-icon" href="../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link href="../publics/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="../publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../publics/css/header.css">
  <link rel="stylesheet" href="../publics/css/footer.css">
  <link rel="stylesheet" href="../publics/css/bande.css">
  <link rel="stylesheet" href="../publics/css/contact.css">
  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>

  <?php
  include('header.php');
  ?>
  <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
    <!-- <input type=" checkbox" id="checkbox" /> -->
    <h1 class="post-img animate__animated animate__fadeInDown" id="word"></h1>
  </section>
  <section id="contact" class="contact-form section-bg">
    <div class="container">
      <div class="row justify-content-center" style=" width: 100%; ">
        <h2 style="text-align: center; font-family: 'Ubuntu',sans-serif; font-weight: 500px;">Contact us now!</h2>
        <div class="col-lg-9 mt-4 mt-lg-0" style="background-color: #fff; padding: 20px 20px 20px 20px; border-radius: 5px; box-shadow: 0 0 30px rgba(214, 215, 216, 0.6);;width:100%; margin-left: 20px;" data-aos="zoom-in" data-aos-delay="100">
          <form action="" method="POST" id="contactForm" class="projetForm">
            <div class="row">

              <div class="col-md-6 form-group">
                <input type="text" name="nom" class="form-control" id="nom" placeholder="Your name">
              </div>
              <div class="col-md-6 form-group mt-3 mt-md-0">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your email">
              </div>
            </div>
            <div class="form-group mt-3">
              <input type="text" class="form-control" name="sujet" id="sujet" placeholder="Suject">
            </div>
            <div class="form-group mt-3">
              <textarea class="form-control" name="message" rows="5" placeholder="Message"></textarea>
            </div>
            <div class="my-3 text-center">
              <span id="succes" style="color: green;"><?php if (isset($succes)) {
                                                        echo $succes;
                                                      } ?></span>
              <span id="error" style="color: red;"><?php if (isset($erreur)) {
                                                      echo $erreur;
                                                    } ?></span>
            </div>
            <div class="text-center">
              <input type="submit" value="Send" name="valider" style="height: 40px; width: 100px;background-color: #EB1566; color:#fff; border: none; border-radius: 5px;">
            </div>
          </form>

        </div>
      </div>
      <div class="container">
        <div class="col-md-12" data-aos="zoom-in" data-aos-delay="100">
          <div class="info-box" style="height: 180px; text-align: center;">
            <i class="bx bx-map"></i>
            <!-- <h3 style="margin-top: 38px;"><i class="bx bx-map" style="color: #009EE2"></i></h3> -->
            <p>Diamniadio, Dakar, Senegal</p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="info-box mt-4" style="height: 180px; text-align: center;">
              <i class=" bx bx-envelope"></i>
              <!-- <h3 style="margin-top: 38px;"><i class=" bx bx-envelope" style="color: #009EE2"></i></h3> -->
              <a href="mailto:jokkolante01@gmail.com" style="color: black; text-decoration: none;">
                <p>jokkolante01@gmail.com</p>
              </a>
            </div>
          </div>
          <div class="col-md-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="info-box mt-4 col-md-12" style="height: 180px; color:  black;">
              <i class="bx bx-phone-call" style="margin-top: -15px;"></i>
              <!-- <h3><i class="bx bx-phone-call" style="color: #009EE2"></i></h3> -->
              <div class="col-md-12" style=" display: flex;">
                <div class="col-md-6" style="display:flex; align-items: center; justify-content: right; width: 45%;">
                  (+221)
                </div>
                <div class="col-md-6" style="text-align: left; width: 55%;">
                  <div class="col-md-6">
                    <a href="tel:(+221)781320056" style="color: black; text-decoration: none;">
                      78 132 00 56
                    </a>
                  </div>

                  <div class="col-md-6">
                    <a href="tel:(+221)781320056" style="color: black; text-decoration: none;">
                      33 871 79 79
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>



  </section>

  <div class="container pb-5 local">
    <h1 style="text-align: center; font-family: 'Ubuntu',sans-serif; font-weight: 500px; margin-top: 50px; margin-bottom: 50px;">Our position</h1>
    <div style="box-shadow: 0 0 30px rgba(214, 215, 216, 0.6);" class="gmap_canvas w-100"><iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/?q=14.7223553,-17.1684993&entry=gps&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://putlocker-is.org"></a><br><a href="https://www.embedgooglemap.net">google html code</a>
      <style>
        .gmap_canvas {
          overflow: hidden;
          background: none !important;
          height: 500px;
          width: 1080px;
        }
      </style>
    </div>
  </div>



  <?php

  include('footer.php');

  ?>


  <script src="../publics/js/contact.js"></script>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  
  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="../publics/js/active.js"></script>
  
  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../publics/js/main.js"></script>
  <script src="../publics/js/main1.js"></script>
  <script src="../publics/js/menu.js"></script>
  <script>
    var
      words = ['Contact'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;
    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>