<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Training</title>

  <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

  <link href="../../publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>

  <link rel="stylesheet" href="../../publics/css/header.css">
  <link rel="stylesheet" href="../../publics/css/footer.css">
  <link rel="stylesheet" href="../../publics/css/formation.css">


  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>


  <?php
  include "../nav/header.php";
  ?>


  <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
    <h1 class="titre animate__animated animate__fadeInDown" id="word"></h1>

  </section>
  <section id="events" class="events">
    <div class="container" data-aos="fade-up">
      <h1 class="" style="text-align: center;font-family: ubuntu;font-weight: 700;font-style:italic;color:#009EE2;margin-top:50px;" data-aos="zoom-in" data-aos-delay="100">Our training courses</h1>

      <div class="row" style="margin-top: 70px;">
        <div class="col-md-6 d-flex align-items-stretch">
          <div class="card">

            <div class="card-img">
              <img src="../../publics/images/events-1.jpg" alt="...">
            </div>
            <div class="card-body card-body1">
              <h5 class="card-title"> Business training</h5>
              <p class="card-text">Vocational training is the process of acquiring the knowledge and skills required in specific occupations or, more broadly, in the job market. This process can take place during initial training (e.g. apprenticeship, vocational high school, etc.) or continuing training.</p>

              <button class="more-link" type="button"> <a href="formation1.php">See more</a></button>
            </div>
          </div>
        </div>
        <div class="col-md-6 d-flex align-items-stretch">
          <div class="card">
            <div class="card-img">
              <img src="../../publics/images/course-1.jpg" alt="...">
            </div>
            <div class="card-body card-body2">
              <h5 class="card-title">Modular courses</h5>
              <p class="card-text">The modularisation of training corresponds to the organisation of the training course around identified training units or modules corresponding to "skill building blocks" or "pieces of professions" and no longer a disciplinary division.</p>

              <button class="more-link" type="button"> <a href="formation2.php">See more</a></button>
            </div>
          </div>

        </div>
      </div>

    </div>
  </section>

  <?php
  include "../nav/footer.php";
  ?>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="../../publics/js/active.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../publics/js/main.js"></script>
  <script src="../../publics/js/main1.js"></script>
  <script src="../../publics/js/menu.js"></script>
  <script>
    var
      words = ['Training'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;

    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>