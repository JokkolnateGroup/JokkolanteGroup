<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Skills training</title>

    <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="http://daneden.me/animate">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

    <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>

    <link rel="stylesheet" href="../../publics/css/header.css">
    <link rel="stylesheet" href="../../publics/css/footer.css">
    <link rel="stylesheet" href="../../publics/css/formation.css">

    <script>
        $(document).ready(function() {
            $(".dropdown").hover(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>

<body>


    <?php
    include "../nav/header.php";
    ?>


    <section id="hero" class="hero  d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
        <h1 class="titre animate__animated animate__fadeInDown" id="word"></h1>

    </section>


    <main id="main">

        <div class="et_pb_text_inner titre animate__animated animate__fadeInDowns" style="font-family: ubuntu, sans-serif;">
            <h1 class="titre animate__animated animate__fadeInDown"> Our training courses <span style="color: #009EE2;">jobs</span> </h1>
        </div>

        <div class="home-motto pad-4" style="margin-top:50px;">
            <div class="container blocs">
                <div class="row">

                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/last-formation.jpg" alt="Clé en main" />
                                    </div>
                                    <p class="">Entrepreneurship</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">
                                        <p class="title">Entrepreneurship</p>
                                    </div>
                                    <p class="content">Entrepreneurship courses teach students to master all the techniques needed to run a business.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/Sha.png" alt="Clé en main" />
                                    </div>
                                    <p class="">UX/UI DESIGN</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">

                                        <p class="title">UX/UI DESIGN</p>
                                    </div>
                                    <p class="content">Web integrators are responsible for the graphic design of the user interface of a website or application. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/cal.png" alt="Performant" />

                                    </div>
                                    <p class="">INFOGRAPHY / VIDEO EDITING</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">
                                        <p class="title">INFOGRAPHY / VIDEO EDITING</p>
                                    </div>
                                    <p class="content">Corporate presence is characterised by a graphic identity. Companies direct their marketing and communication strategies towards the creation of different content formats.</p>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/app.png" alt="Clé en main" />
                                    </div>
                                    <p class="">DIGITAL MARKETING</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">
                                        <p class="title">DIGITAL MARKETING</p>
                                    </div>
                                    <p class="content">Digital marketing refers to all the marketing techniques used to promote products and services through digital media and channels. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/b.png" alt="Clé en main" />

                                    </div>
                                    <p class="">Web Developer</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">
                                        <p class="title">Web Developer</p>
                                    </div>
                                    <p class="content">Web developers carry out all the technical functions of a website. He or she designs existing bespoke sites according to the project and the customer's requirements.</p>

                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4 dis-flex">
                        <div class="flip-card-services">
                            <div class="flip-card-inner-services" data-aos="zoom-in" data-aos-delay="100">
                                <div class="flip-card-front-services box-with-shadow3">
                                    <div class="img">
                                        <img src="../../publics/images/Vectors2.png" alt="Clé en main" />
                                    </div>
                                    <p class="">Digital referent</p>
                                </div>
                                <div class="flip-card-back-services">
                                    <div class="d-flex mb-3">
                                        <p class="title">Digital referent</p>
                                    </div>
                                    <p class="content">Référent⋅e Digital.e is a job that is developing in response to needs and will be increasingly in demand because its cross-disciplinary skills mean it can adapt and evolve.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>


    <?php

    include('../nav/footer.php');

    ?>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="../../publics/js/active.js"></script>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>
  
    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="../../publics/js/main.js"></script>
    <script src="../../publics/js/main1.js"></script>
    <script src="../../publics/js/menu.js"></script>
    <script>
        var
            words = ['Skills training'],
            part,
            i = 0,
            offset = 0,
            len = words.length,
            forwards = true,
            skip_count = 0,
            skip_delay = 5,
            speed = 200;

        var wordflick = function(idH1, tab) {
            setInterval(function() {
                if (forwards) {
                    if (offset >= tab[i].length) {
                        ++skip_count;
                        if (skip_count == skip_delay) {
                            forwards = false;
                            skip_count = 0;
                        }
                    }
                } else {
                    if (offset == 0) {
                        forwards = true;
                        i++;
                        offset = 0;
                        if (i >= len) {
                            i = 0;
                        }
                    }
                }
                part = tab[i].substr(0, offset);
                if (skip_count == 0) {
                    if (forwards) {
                        offset++;
                    }
                    // else {
                    //   offset--;
                    // }
                }
                $(idH1).text(part);
            }, speed);
        };

        $(document).ready(function() {
            wordflick('#word', words);
        });
    </script>

</html>