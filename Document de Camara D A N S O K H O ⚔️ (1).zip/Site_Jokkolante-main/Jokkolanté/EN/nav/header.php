<header class="mb-4 fixed-top">
  <!-- Jumbotron -->
  <div class="p-2 text-center border-bottom Jumbotron" style="color: #fff">
    <div class="container">
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <!-- Right elements -->
        <div class="col-lg-4 col-md-4 col-sm-4 justify-content-center justify-content-md-start align-items-center d-lg-flex fist">
          <a class="text-reset" href="tel:(+221)338717979">
            <img src="../../publics/images/Group448.svg" class="mb-1" />
            <span class="d-xl-inline-block">(+221) 33 871 79 79</span>
          </a>
        </div>
        <!-- Right elements -->

        <!-- Center elements -->
        <div class="col-lg-4 col-md-4 col-sm-4 d-lg-block second">
          <a href="mailto:jokkolante01@gmail.com" class="text-reset">
            <img src="../../publics/images/Group382.svg" alt="" class="mb-1" />
            <span class="d-xl-inline-block">Jokkalante01@gmail.com</span>
          </a>
        </div>
        <!-- Center elements -->

        <!-- Right elements -->
        <div class="col-lg-4 col-md-4 col-sm-4 ms-2 d-flex justify-content-md-end align-items-center three">
          <span class="d-xl-inline-block me-2">Follow us on</span>
          <a class="text-reset" href="https://twitter.com/jokkolante?t=gE7J4WZzU6kc2MukiG2_zw&s=09">
            <img src="../../publics/images/Group373.svg" alt="" />
          </a>
          <a class="text-reset" href="https://www.linkedin.com/company/jokkolante">
            <img src="../../publics/images/Group377.svg" alt="" />
          </a>
          <a class="text-reset" href="https://www.facebook.com/Jokkolantegroup?mibextid=LQQJ4d">
            <img src="../../publics/images/Group380.svg" alt="" />
          </a>
          <a class="text-reset" href="https://instagram.com/jokkolantegroup_officiel?igshid=Yjk4NWM2ZWVkMw==">
            <img src="../../publics/images/Group378.svg" alt="" />
          </a>
        </div>
        <!-- Right elements -->
      </div>
    </div>
  </div>
  <!-- Jumbotron -->
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container" data-aos="zoom-in" data-aos-delay="100">
      <a href="../index.php" class="navbar-brand mx-2 py-2" style="margin-left: 0px !important; margin-right: 0px !important;"><img src="../../publics/images/logo-remove.png" alt="" /></a>
      <!-- <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button> -->
      <div class="toggle">
        <i class="fas fa-bars ouvrir" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"></i>
        <i class="fas fa-times fermer" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"></i>
      </div>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto mb-2 mb-lg-0">
          <div class="nav-item active">
            <a href="../index.php" class="nav-link"><span>Home</span></a>
          </div>
          <div class="nav-item">
            <a href="../apropos.php" class="nav-link"><span>About us</span></a>
          </div>
          <div class="nav-item">
            <div class="nav-link">
              <a href="../services/service.php"><span>Services</span></a>

              <div class="dropdown">
                <div class="drop-toggle justify-content-center" style="margin-left: 5px;">
                  <i class="dropdown-toggle" data-toggle="dropdown"></i>
                </div>
                <div class="dropdown-menu animated flipInX drop-menu1">
                  <a href="../services/service1.php" class="dropdown-item">
                    <p>Content creation</p>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div class="nav-item">
            <div class="nav-link">
              <a href="../formations/formation.php"><span>Training</span>
              </a>

              <div class="dropdown justify-content-center">

                <div class="drop-toggle" style="margin-left: 5px;">
                  <i class="dropdown-toggle" data-toggle="dropdown"></i>
                </div>


                <div class="dropdown-menu animated flipInX drop-menuE">
                  <a href="../formations/formation1.php" class="dropdown-item">
                    <p>Skills training</p>

                  </a>
                  <a href="../formations/formation2.php" class="dropdown-item">
                    <p>Modular Training</p>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div class="nav-item">
            <a href="../contact.php" class="nav-link contact"><span>Contact</span></a>
          </div>
        </div>
        <div class="navbar-nav ms-auto mb-2 mb-lg-0">
          <!-- <div class="nav-item langue">
            <a href="" class="nav-link"><img src="../../publics/images/fr.jpg" alt="" style="margin-right: 5px" />FR</a>
          </div> -->

          <div class="nav-item langue">
            <div class="nav-link">
            <div>
            <a href="../index.php"><span  style="margin-left: 0px;">FR</span></a>

            </div>

              <div class="dropdown">
                <div class="drop-toggle justify-content-center" style="margin-left: 5px;">
                <div class="active">
                <a href="../../index.php"><span>EN</span></a>
                </div>
              </div>
               
              </div>
            </div>
          </div>
          <div class="pb-lg-0 pb-5 text-center">
            <a href="../projet.php" class="projet">
              <p>I have a project</p>
            </a>
          </div>
        </div>
      </div>
    </div>
  </nav>
</header>