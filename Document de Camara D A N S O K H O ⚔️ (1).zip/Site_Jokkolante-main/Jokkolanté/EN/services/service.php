<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Services</title>

  <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

  <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../../publics/css/header.css">
  <link rel="stylesheet" href="../../publics/css/footer.css">
  <link rel="stylesheet" href="../../publics/css/service.css">


  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>

  <?php
  include('../nav/header.php')
  ?>
  <section id="hero" class="hero1 d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
    <h1 class=" animate__animated animate__fadeInDown" id="word"></h1>
  </section>

  <section id="featured" class="service">
    <div class="container">
      <h2 class=" animate__animated animate__fadeInDown" data-aos="zoom-in" data-aos-delay="100">Our services</h2>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/2.png" alt="">
              </div>
              <div class="card-body">
                <h3>Content creation Graphic design</h3>
                <p>Graphic design is a design activity aimed at implementing and conceiving the production of visual
                  visual communication combining image and text, in print or on screen.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/Vector.png" alt="">
              </div>
              <div class="card-body">
                <h3>Social networks</h3>
                <p>We design your digital strategy to communicate effectively with your target audience. From
                  developing your communication strategy, preparing your deadlines and executing and maintaining
                  maintenance of your networks.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/1.png" alt="">
              </div>
              <div class="card-body">
                <h3>AUDIOVISUAL Production</h3>
                <p>Strategic and creative agency specialising in the creation of films and videos for brands and
                  companies. We produce video content for a wide range of communication and distribution media
                  to support your business, digital and audiovisual strategy.</p>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/Vector2.png" alt="">
              </div>
              <div class="card-body">
                <h3>Digital Strategy</h3>
                <p>A digital strategy is a plan of action implemented across a company's various digital media.
                  digital media,
                  i.e. the web, with the aim of achieving the brand's overall objectives, whether these be
                  objectives
                  or brand awareness.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/3.png" alt="">
              </div>
              <div class="card-body">
                <h3>Web development</h3>
                <p>We develop sites that are ﬁable, scalable and design-led. The customer journey is thought through
                  every
                  every detail. E-commerce site - Showcase site - UX / UI Design - SEO optimisation / Natural referencing - Functional specifications - WordPress / WiziShop / PrestaShop.
                  Functional specifications - WordPress /WiziShop / PrestaShop.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">

                <img src="../../publics/images/Vector4.png" alt="">
              </div>
              <div class="card-body">
                <h3>AUDIOVISUAL Production</h3>
                <p>L'e–réputation rassemble l'image d'une entreprise qu'elle a su générer sur Internet mais aussi la
                  réputation que les internautes donnent à l'entreprise via les réseaux sociaux, blogs ou forums.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/production.png" alt="">
              </div>
              <div class="card-body">
                <h3>Production of digital services on mesutres (The App)</h3>
                <p>Stay in control of your destiny by optimising your working methods. As the way work is organised continues to evolve and companies are forced to equip themselves with new, more effective communication and management tools, the digital transformation of businesses is essential.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/trainning.png" alt="">
              </div>
              <div class="card-body">
                <h3>Training</h3>
                <p>Jokkolante Group has developed an integrated range of consulting and capacity-building services.
                  Training is provided by various trainers who bring their expertise in coaching techniques and their various applications.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">

                <img src="../../publics/images/etude.png" alt="">
              </div>
              <div class="card-body">
                <h3>Conceptual studies</h3>
                <p>From the idea to the realisation of a project, a conceptual study enables you to think, to set up a problem-solving process aimed at innovation, in a world where evolution is becoming the norm and where the ability to adapt is vital. Our expertise can help you structure your vision for successful implementation.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>


  <?php

  include('../nav/footer.php');

  ?>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="../../publics/js/active.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../publics/js/main.js"></script>
  <script src="../../publics/js/main1.js"></script>
  <script src="../../publics/js/menu.js"></script>
  <script>
    var
      words = ['Services'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;

    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>