<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Content creation</title>

  <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../../publics/css/header.css">
  <link rel="stylesheet" href="../../publics/css/footer.css">
  <link rel="stylesheet" href="../../publics/css/service.css">


  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>

  <?php
  include('../nav/header.php')
  ?>
  <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">

    <h1 class=" animate__animated animate__fadeInDown" id="word"></h1>
  </section>
  <section id="featured" class="service">
    <div class="container">
      <h2 class=" animate__animated animate__fadeInDown" data-aos="zoom-in" data-aos-delay="100">Nos Services</h2>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box0 animate__animated animate__fadeInDown">

            <div class="card-body1" id="typedtext">

              <h4 id="h4">SERVICES</h4>
              <h2 id="h2">Content creation Graphic design</h2>
              <p id="p">Graphic design is a conceptual activity aimed at creating and designing visual communication combining image and text, in print or on screen.</p>
              <a href="service.php" class="bnt"><img src="../../publics/images/4.png" alt="">SEE ALL SERVICES</a>

            </div>

          </div>
        </div>

        <div class="row col-md-8" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">

                  <img src="../../publics/images/2.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Graphics</h3>
                  <p>Graphic design is a discipline that involves creating, selecting and using graphic elements to create a communication and/or cultural object. It is a way of representing.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">

                  <img src="../../publics/images/5.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Motion Design</h3>
                  <p>Motion design, also known as graphic animation, animated graphics, motion design or animated graphic design is a form of visual art ...</p>

                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">
                  <img src="../../publics/images/3.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Web Site Creation</h3>
                  <p>We offer you a high-quality website creation service to help you develop your business on the Internet.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">
                  <img src="../../publics/images/6.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>2D/3D design</h3>
                  <p>Although 3D design has been widely democratised, some companies are still clinging to their 2D habits.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
  </section>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <?php

  include('../nav/footer.php');

  ?>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="../../publics/js/active.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../publics/js/main.js"></script>
  <script src="../../publics/js/main1.js"></script>
  <script src="../../publics/js/menu.js"></script>
  <script src="../../publics/js/service.js"></script>

  <script>
    var
      words = ['Content Creation'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;

    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>