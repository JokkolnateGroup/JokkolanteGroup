<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title> A Propos</title>

    <link rel="icon" type="image/x-icon" href="publics/images/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="http://daneden.me/animate">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

    <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
    <link rel="stylesheet" href="publics/css/header.css">
    <link rel="stylesheet" href="publics/css/footer.css">
    <link rel="stylesheet" href="publics/css/apropos.css">
    <link rel="stylesheet" href="publics/css/experts.css">
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>
</head>

<body>

    <?php
    include('html/header.php')
    ?>
    <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
        <h1 class="post-img animate__animated animate__fadeInDown" id="words"></h1>
    </section>

    <section class="hero-apropos1">
        <div class="container-fluid app">
            <div class="row justify-content-center gy-3" data-aos="zoom-in" data-aos-delay="100">
                <div class="col-md-6 mb-4">
                    <article class="block-wrap1">
                        <div class="col-12 ">
                            <div class="block-propos">
                                <img src="publics/images/localisation.png" alt="">
                                <div class="card-body">
                                    <p>Notre agence est un partenaire stratégique pour les entreprises qui souhaitent renforcer leur visibilité et leur engagement auprès de leur public cible.</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-6 mb-4">
                    <article class="block-wrap1">
                        <div class="col-12 ">
                            <div class="block-propos1">
                                <div class="card-body">
                                    <p>Nous sommes passionnés par la création de campagnes innovantes et efficaces qui permettent à nos clients de se démarquer de la concurrence.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 ">
                            <div class="block-propos1">
                                <div class="card-body">
                                    <div class="service-bouton">
                                        <a href="html/Services/service.php"><img src="publics/images/edit.png" alt="">NOS SERVICES</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>

            </div>
        </div>
    </section>
    <div class="container">

        <p class="textes animate__animated animate__fadeInDown" style="margin-top:50px;" data-aos="fade-down" data-aos-delay="100">
            Pourquoi nous confier vos projets créatifs ? </p>

        <div class="row row-cols-1 row-cols-md-3 g-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>01</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Une équipe</h5>

                        <p class="card-text">100% Disponible</p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>02</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Un bureau physique</h5>

                        <p class="card-text">Pour garantir une proximité</p>
                    </div>

                </div>
            </div>
            <div class="col">

                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>03</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Rapport Qualité/Prix</h5>

                        <p class="card-text">Imbattable</p>
                    </div>

                </div>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-3 g-4 bloc2" data-aos="zoom-in" data-aos-delay="100">
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>04</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Notre Créativité</h5>

                        <p class="card-text">Au service de vos projets </p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body  numero">
                        <p>05</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">Un studio graphique</h5>

                        <p class="card-text">Pensé pour tous vos projets</p>
                    </div>

                </div>
            </div>
            <div class="col">
                <div class="container" style="display:flex;">
                    <div class="card-body numero">
                        <p>06</p>
                    </div>
                    <div class="card-body bloc">

                        <h5 class="card-title">La garantie d'un budget</h5>

                        <p class="card-text">Respecté et optimisé</p>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <section oncontextmenu='return false' class="snippet-body align-items-center justify-content-center">

        <div class="container">
            <div class="row">
                <div class="col-md-1à mb-4">
                    <article class="block-wrap1">
                        <div class="col-12">
                            <div class="block-propos" data-aos="fade-down" data-aos-delay="100">
                                <div class="card-body">

                                    <p class="title-section-qsn-vc"><span class="trait-title-section-qsn-vc">Des
                                            ex</span>perts</span> à votre service</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-12">
                    <div id="news-slider" class="owl-carousel ">
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/fa.svg" alt="">

                                <div class="over-layer">
                                    <img src="publics/images/fa1.svg" alt="">
                                   
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> MBENGUE </a>
                                </h3>
                                <p class="post-description">La Dynamique</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/dans.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/dans1.svg" alt="">
                                    
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> DANSOKHO </a>
                                </h3>
                                <p class="post-description">L'Optimiste</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/ous.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/ous1.svg" alt="">
                                    
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">AW </a>
                                </h3>
                                <p class="post-description">Le Visionnaire</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/ch.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/ch1.svg" alt="">
                                    
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIAW</a>
                                </h3>
                                <p class="post-description">L'Original</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/anta.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/anta1.svg" alt="">
                                    
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> AW </a>
                                </h3>
                                <p class="post-description">La Reine</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/sey.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/sey1.svg" alt="">
                                    
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIOUF </a>
                                </h3>
                                <p class="post-description">Le Zen</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
    </section>

    <?php

    include('html/footer.php');

    ?>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="publics/js/active.js"></script>
    
    <!-- <script src='https://code.jquery.com/jquery-1.12.0.min.js'></script> -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>
    <script type='text/javascript'>
        $(document).ready(function() {
            $("#news-slider").owlCarousel({
                items: 5,
                itemsDesktop: [1199, 5],
                itemsDesktopSmall: [980, 3],
                itemsMobile: [600, 2],
                navigation: true,
                navigationText: ["", ""],
                pagination: true,
                autoPlay: true,
                interval: 200,
                cycle: true
            });

        });
    </script>

    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script src="publics/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="publics/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="publics/js/main.js"></script>
    <script src="publics/js/main1.js"></script>
    <script src="publics/js/menu.js"></script>
    <script>
        var
            pros = ['A propos'],
            part,
            i = 0,
            offset = 0,
            len = words.length,
            forwards = true,
            skip_count = 0,
            skip_delay = 5,
            speed = 200;

        var wordflick = function(idH1, tab) {
            setInterval(function() {
                if (forwards) {
                    if (offset >= tab[i].length) {
                        ++skip_count;
                        if (skip_count == skip_delay) {
                            forwards = false;
                            skip_count = 0;
                        }
                    }
                } else {
                    if (offset == 0) {
                        forwards = true;
                        i++;
                        offset = 0;
                        if (i >= len) {
                            i = 0;
                        }
                    }
                }
                part = tab[i].substr(0, offset);
                if (skip_count == 0) {
                    if (forwards) {
                        offset++;
                    }
                    // else {
                    //   offset--;
                    // }
                }
                $(idH1).text(part);
            }, speed);
        };

        $(document).ready(function() {
            wordflick('#words', pros);
        });
    </script>
</body>

</html>