<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Services</title>

  <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

  <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../../publics/css/header.css">
  <link rel="stylesheet" href="../../publics/css/footer.css">
  <link rel="stylesheet" href="../../publics/css/service.css">


  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>

  <?php
  include('../navbar_service/header.php')
  ?>
  <section id="hero" class="hero1 d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
    <h1 class=" animate__animated animate__fadeInDown" id="word"></h1>
  </section>

  <section id="featured" class="service">
    <div class="container">
      <h2 class=" animate__animated animate__fadeInDown" data-aos="zoom-in" data-aos-delay="100">Nos Services</h2>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/2.png" alt="">
              </div>
              <div class="card-body">
                <h3>Création de contenu Design graphique</h3>
                <p>Le design graphique est une activité de conception visant à mettre en œuvre et à concevoir la
                  réalisation d'une communication visuelle combinant image et texte, imprimé ou sur écran.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/Vector.png" alt="">
              </div>
              <div class="card-body">
                <h3>Réseaux sociaux</h3>
                <p>Nous concevons votre stratégie digitale pour communiquer efficacement auprès de votre cible. De
                  l'élaboration de votre stratégie de communication, la préparation de vos délais jusqu'à l'exécution et
                  la maintenance de vos réseaux.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/1.png" alt="">
              </div>
              <div class="card-body">
                <h3>Production AUDIOVISUELLE</h3>
                <p>Agence stratégique et créative spécialisée dans la création de films et vidéos pour les marques et
                  entreprises. Nous produisons des contenus vidéo pour des supports de communication et de diffusion
                  variés pour vous accompagner dans votre stratégie entrepreneuriale, digitale et audiovisuelle.</p>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/Vector2.png" alt="">
              </div>
              <div class="card-body">
                <h3>Stratégie Digitale</h3>
                <p>Une stratégie digitale est un plan d'action mené sur les différents supports digitaux d'une
                  entreprise,
                  à savoir le web dans le but d'atteindre les objectifs globaux de la marque, qu'il s'agisse des
                  objectifs
                  commerciaux ou de la notoriété.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/3.png" alt="">
              </div>
              <div class="card-body">
                <h3>Développement web</h3>
                <p>Nous développons des sites ﬁables, évolutifs et design. Le parcours client est pensé dans les
                  moindres
                  détails. Site E-commerce – Site vitrine – UX / UI Design – Optimisation SEO / Référencement naturel –
                  Cahier des charges fonctionnel – WordPress /WiziShop / PrestaShop.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">

                <img src="../../publics/images/Vector4.png" alt="">
              </div>
              <div class="card-body">
                <h3>Production AUDIOVISUELLE</h3>
                <p>L'e–réputation rassemble l'image d'une entreprise qu'elle a su générer sur Internet mais aussi la
                  réputation que les internautes donnent à l'entreprise via les réseaux sociaux, blogs ou forums.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/production.png" alt="">
              </div>
              <div class="card-body">
                <h3>Productions de services digitales sur mesutres ( Des App)</h3>
                <p>Restez maître de votre destin en optimisant vos méthodes de travail. Parce que l’organisation du travail évolue en permanence et que les entreprises sont contraintes de se doter de nouveaux outils plus performants, de communication ou de gestion, la transformation digitale des entreprises est indispensable.</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">
                <img src="../../publics/images/trainning.png" alt="">
              </div>
              <div class="card-body">
                <h3>Training</h3>
                <p>Jokkolante Group a développé une offre intégrée de services conseil et renforcement des capacités.
                  La formation est assurée par différents formateurs qui apportent leur expertise sur les techniques du coaching et sur leurs différentes applications.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4 mt-4 mt-lg-0">
          <div class="icon-box animate__animated animate__fadeInDown">
            <div class="bloc0">
              <div class="image">

                <img src="../../publics/images/etude.png" alt="">
              </div>
              <div class="card-body">
                <h3>Etudes conceptuelles</h3>
                <p>De l'idée à la réalisation d'un projet, l'étude conceptuelle permet de penser, de mettre un processus de résolution de problèmes visant à l'innovation, dans un monde où l'évolution devient une normalité et où la faculté de s'adapter est vitale. Notre expertise vous accompagne à structurer votre vision pour une mise en oeuvre réussie.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>


  <?php

  include('../navbar_service/footer.php');

  ?>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="../../publics/js/active.js"></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../publics/js/main.js"></script>
  <script src="../../publics/js/main1.js"></script>
  <script src="../../publics/js/menu.js"></script>
  <script>
    var
      words = ['Services'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;

    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>