<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Création de contenus</title>

  <link rel="icon" type="image/x-icon" href="../../publics/images/icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="http://daneden.me/animate">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
  <link rel="stylesheet" href="../../publics/css/header.css">
  <link rel="stylesheet" href="../../publics/css/footer.css">
  <link rel="stylesheet" href="../../publics/css/service.css">


  <script>
    $(document).ready(function() {
      $(".dropdown").hover(function() {
        var dropdownMenu = $(this).children(".dropdown-menu");
        if (dropdownMenu.is(":visible")) {
          dropdownMenu.parent().toggleClass("open");
        }
      });
    });
  </script>
</head>

<body>

  <?php
  include('../navbar_service/header.php')
  ?>
  <section id="hero" class="hero d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">

    <h1 class=" animate__animated animate__fadeInDown" id="word"></h1>
  </section>
  <section id="featured" class="service">
    <div class="container">
      <h2 class=" animate__animated animate__fadeInDown" data-aos="zoom-in" data-aos-delay="100">Nos Services</h2>
      <div class="row" data-aos="zoom-in" data-aos-delay="100">
        <div class="col-lg-4">
          <div class="icon-box0 animate__animated animate__fadeInDown">

            <div class="card-body1" id="typedtext">

              <h4 id="h4">PRESTATION</h4>
              <h2 id="h2">Création de contenu Design graphique</h2>
              <p id="p">Le design graphique est une activité de conception visant à mettre en œuvre et à concevoir la réalisation d'une communication visuelle combinant image et texte, sur imprimé ou sur écran.</p>
              <a href="service.php" class="bnt"><img src="../../publics/images/4.png" alt="">VOIR TOUS LES SERVICES</a>

            </div>

          </div>
        </div>

        <div class="row col-md-8" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">

                  <img src="../../publics/images/2.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Graphique</h3>
                  <p>Le graphique est une discipline qui consiste à créer, choisir et utiliser des éléments graphiques pour élaborer un objet de communication et/ou de culture. C'est une manière de représenter.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">

                  <img src="../../publics/images/5.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Conception De Mouvement</h3>
                  <p>Conception de Mouvement, aussi appelé animation graphique, graphisme animé, conception du mouvement ou conception graphique animée est une forme d'art visuel …</p>

                </div>
              </div>
            </div>
          </div>

          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">
                  <img src="../../publics/images/3.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Création De Sites Web</h3>
                  <p>Nous mettons à votre disposition un service de création site web de qualité afin de vous permettre de développer votre activité sur internet.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="icon-box1 animate__animated animate__fadeInDown">
              <div class="bloc1">
                <div class="image">
                  <img src="../../publics/images/6.png" alt="">
                </div>
                <div class="card-body2">
                  <h3>Conception 2D/3D</h3>
                  <p>Bien que la conception 3D se soit largement démocratisée, certaines entreprises restent encore accrochées à leurs habitudes en se limitant à la 2D.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
  </section>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <?php

  include('../navbar_service/footer.php');

  ?>

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <!-- <script src="../../publics/js/active.js"></script> -->

  <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

  <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
  <script src="../../publics/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../../publics/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../../publics/js/main.js"></script>
  <script src="../../publics/js/main1.js"></script>
  <script src="../../publics/js/menu.js"></script>
  <script src="../../publics/js/service.js"></script>

  <script>
    var
      words = ['Création de contenu'],
      part,
      i = 0,
      offset = 0,
      len = words.length,
      forwards = true,
      skip_count = 0,
      skip_delay = 5,
      speed = 200;

    var wordflick = function(idH1, tab) {
      setInterval(function() {
        if (forwards) {
          if (offset >= tab[i].length) {
            ++skip_count;
            if (skip_count == skip_delay) {
              forwards = false;
              skip_count = 0;
            }
          }
        } else {
          if (offset == 0) {
            forwards = true;
            i++;
            offset = 0;
            if (i >= len) {
              i = 0;
            }
          }
        }
        part = tab[i].substr(0, offset);
        if (skip_count == 0) {
          if (forwards) {
            offset++;
          }
          // else {
          //   offset--;
          // }
        }
        $(idH1).text(part);
      }, speed);
    };

    $(document).ready(function() {
      wordflick('#word', words);
    });
  </script>
</body>

</html>