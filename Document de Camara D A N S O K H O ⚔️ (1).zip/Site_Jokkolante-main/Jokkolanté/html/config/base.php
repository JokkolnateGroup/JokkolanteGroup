<?php
// $servername = "localhost";
// $username = "root";
// $password = "";

// Création de la connexion
$conn = new PDO('mysql:host=mysql-drame.alwaysdata.net;dbname=drame_jokkolante;charset=utf8', 'drame', 'Smbdrm20');

?>