<footer class="footer-content">
    <div class="footer-first">
        <div class="container">
            <div class="row">
                
                <div class="col-md-3">
                    <div class="mt-4 mb-4">
                        <img style="margin-top: 10px;" src="publics/images/logo-remove.png" class="img-fluid" alt="Groupe Lika"  width="200" />
                    </div>
                    <div class="address">
                        <p style="color:#fff; width:200px; "><img src="publics/images/Group1.png" wid   th="50px" height="50px" alt="" style="margin-right: 10px; margin-top: -30px;"> Dakar, Sénégal</p>
                        <img src="publics/images/Group.png" width="45px" height="45px" alt="" style="margin-left: 0px; margin-top: 0px">
                        <p style="color:#fff; width:200px;margin-left:60px;margin-top:-35px;"> Diamniadio,
                            Cité <br> Fonctionnaire, Villa 765</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <h4 class="footer-title mt-5" style="font-family: ubuntu, sans-serif;">Nos solutions</h4>
                    <ul class="list-unstyled">
                        <li class="">Developpement web et mobile</li>
                        <li class="">Design graphique</li>
                        <li class="">Marketing digital</li>
                        <li class="">Video plublicitaire</li>
                        <li class="">Publicité en ligne</li>
                        <li class="">Réseaux d'enseignes</li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h4 class="footer-title mt-5" style="font-family: ubuntu, sans-serif;">Vos besoins</h4>
                    <ul class="list-unstyled">
                        <li class="">Développer votre visibilité</li>
                        <li class="">Attirer des clients</li>
                        <li class="">Booster Votre business</li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h4 class="footer-title mt-5" style="font-family: ubuntu, sans-serif;">SPÉCIALITÉS</h4>
                    <ul class="list-unstyled">
                        <li class="">Création de contenu</li>
                        <li class="">Production audiovisuelle</li>
                        <li class="">Conseil Formation</li>
                        <li class="">Développement web</li>
                        <li class="">Performance Conversion</li>
                        <li class="">Gestion des réseaux sociaux</li>
                    </ul>
                </div>
                
            </div>
        </div>
        <div class="footer-second pt-1">
            <div class="container">
                <div class="hr-footer">
                    <hr>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center" style="color: #009EE2;margin-top: -5px;">
                        <small style="font-size:15px;">
                            &copy; 2023 Tous droits réservés-<span style="color: #fff;">Jokkolante GROUP</span>
                        </small>
                    </div>
                </div>
            </div>
        </div>
</footer>
<div id="preloader"></div>
<div class="back-to-top" style="width:50px; height:50px;">
  <li class="list-inline-item" style="margin-top: 10px;margin-left:10px;">
    <a href="https://wa.me/221781320056" class="text-white"><i><img src="publics/images/w-removebg-preview.png" width="30px" alt=""></i> </a>
  </li>
</div>