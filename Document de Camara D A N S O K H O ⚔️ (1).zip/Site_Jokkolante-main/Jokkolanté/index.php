<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title> Accueil</title>

    <link rel="icon" type="image/x-icon" href="publics/images/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="http://daneden.me/animate">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

    <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
    <link rel="stylesheet" href="publics/css/header.css">
    <link rel="stylesheet" href="publics/css/footer.css">
    <link rel="stylesheet" href="publics/css/accueil.css">
    <link rel="stylesheet" href="publics/css/experts.css">

    <script>
        $(document).ready(function() {
            $(".dropdown-toggle").click(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>
</head>

<body>

    <?php
    include('html/header.php')
    ?>
    <section id="hero" class="hero1 d-flex align-items-center section-bg" data-aos="fade-down" data-aos-delay="100">
        <h1 class="post-img animate__animated animate__fadeInDown" id="word"></h1>
    </section>

    <div class="titre" data-aos="zoom-in" data-aos-delay="100">
        <h1>Découvrez nos différents services</h1>
        <p>Vous avez le choix.</p>
    </div>

    <section id="count" class="count">
        <div class="container cont1">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
                <div class="col-lg-6 col-md-6">
                    <div class="count-box cont1">
                        <span> 01</span>
                        <h5>Création graphique</a></h5>
                        <p>JOKKOLANTE GROUP vous aide à créer l’identité graphique à l’image de votre entreprise. Savoir faire professionnel. Suivi Personnalisé. Prestations sur-mesure. Adoptez le positionnement idéal grâce à une identité graphique singulière et reconnaissable.</p>
                        <div class="trait">

                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <div class="count-box cont1">
                        <span> 02</span>
                        <h5>Communication Digitale</h5>
                        <p>Nous concevons votre stratégie digitale pour communiquer efficacement auprès de votre cible. De l’élaboration de votre stratégie de communication, la préparation de vos timelines jusqu’à l’exécution et la maintenance de vos réseaux.</p>
                        <div class="trait">
                        </div>

                    </div>
                </div>

            </div>

        </div>
        <div class="container">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
                <div class="col-lg-6 col-md-6">
                    <div class="count-box cont3">
                        <span> 03</span>
                        <h5>Développement Web</a></h5>
                        <p>Nous développons des sites ﬁables, évolutifs et design. Le parcours client est pensé dans les moindres détails. Nous prenons en charge l’intégralité de votre projet : de l’élaboration des cahiers de charges, la rédaction du contenuet le développement.</p>
                        <div class="trait">

                        </div>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6">
                    <div class="count-box cont4">
                        <span> 04</span>
                        <h5>Production Audiovisuelle</h5>
                        <p>JOKKOLANTE GROUP est votre partenaire spécialisé dans la production Audiovisuelle. Nous produisons des contenus vidéo et photos pour des supports de communication et de diffusion variés (tv, internet, réseaux sociaux … )
                        </p>
                        <div class="trait">

                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <div class="row modif col-md-12" style="background-image: url(publics/images/Group352.jpg); background-size: contain;background-position:center;background-repeat: no-repeat;">
        <div class="col-md-5" id="image">
            <img src="publics/images/Group2.png" class="img-fluid" alt="Image" data-aos="zoom-out" data-aos-delay="100">

        </div>
        <div class="col-md-5" id="text" data-aos="fade-down" data-aos-delay="100">
            <h2>
                Une méthode simple pour un plan de communication qui fait du buzz</h2>
            <p>
                Notre seule obsession c’est de booster la croissance de nos clients. Nous avons mis en place une méthode de
                gestion unique pour automatiser toutes les tâches répétitives. Ainsi, nous nous concentrons sur l’essentiel pour
                créer une stratégie performante. Notre force c’est la créativité, une gestion rigoureuse, des outils performants
                & une équipe à votre écoute.</p>
            <div class="bt">
                <p>LA RUCHE BOURDONNE DE CREATIVITE</p>
            </div>
        </div>
        <section id="counts" class="section-bg">
            <div class="container">
                <h2 data-aos="fade-down" data-aos-delay="100">Nos chiffres clés</h2>
                <div class="row" id="chiffre" data-aos="zoom-in" data-aos-delay="100">

                    <div class="col-md-3">
                        <div class="count-box1">
                            <span data-purecounter-start="0" data-purecounter-end="10" data-purecounter-duration="1" class="purecounter"></span>
                            <p>
                                Projets réalisés</p>
                            <h1>|</h1>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="count-box1">
                            <span data-purecounter-start="0" data-purecounter-end="05" data-purecounter-duration="1" class="purecounter"></span>
                            <p>
                                Campagnes réalisées</p>
                            <h1>|</h1>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="count-box1">
                            <span data-purecounter-start="0" data-purecounter-end="175" data-purecounter-duration="1" class="purecounter"></span>
                            <p>
                                Clients</p>
                            <h1>|</h1>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="count-box1">
                            <span data-purecounter-start="0" data-purecounter-end="01" data-purecounter-duration="1" class="purecounter"></span>
                            <p>
                                Pays partenaires</p>
                            <h1>|</h1>
                        </div>
                    </div>

                </div>

            </div>
        </section>
    </div>

    <section id="count" class="count" style="margin-top:-10px;width:100%;clip-path: polygon(0 10%, 100% 0, 100% 100%, 0% 100%);">
        <div class="container-fluid py-5">
            <div class="row">
                <div class="col-md-1à mb-4">
                    <article class="block-wrap1">
                        <div class="col-12">
                            <div class="block-propos">
                                <div class="card-body" style="margin-top: 50px;" data-aos="fade-down" data-aos-delay="100">

                                    <h2> <span class="trait-title-section-qsn-vc">Petit ou</span> Grand SEULE <span>LA</span> <br> CROISSANCE COMPTE<span>.</span></h2>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>

                <div id="demo" class="carousel slide" data-bs-ride="carousel">

                    <div class="et_pb_text_inner" style="text-align: center;margin-top: 20px;" data-aos="fade-down-right" data-aos-delay="100">

                        <div class="row  mb-3 mr-2" style="justify-content: end;">
                            <div class="col-lg-2 col-md-6 mb-2 pt-3 px-lg-5 ">

                            </div>
                        </div>

                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="cards-wrapper">
                                    <div class="box2 text-center">
                                        <img src="publics/images/logo-free.jpg" alt="" style="box-shadow: 0 1px 0 0 #EB1566; border: 1px solid #EB1566;">
                                    </div>

                                    <div class="box2 text-center">
                                        <img src="publics/images/logo-expresso.png" alt="" style="box-shadow: 0 1px 0 0 #22427C; border: 1px solid #22427C;">
                                    </div>

                                    <div class="box2 text-center ">
                                        <img src="publics/images/logo-pro.jpg" alt="" style="box-shadow: 0 1px 0 0 #EB1566; border: 1px solid #EB1566;">
                                    </div>

                                    <div class="box2 text-center ">
                                        <img src="publics/images/logo-atos.jpg" alt="" style="box-shadow: 0 1px 0 0 #007FFF; border: 1px solid #007FFF;">
                                    </div>
                                </div>

                            </div>

                            <div class="carousel-item">
                                <div class="cards-wrapper">
                                    <div class="box2 text-center">
                                        <img src="publics/images/logo-free.jpg" alt="" style="box-shadow: 0 1px 0 0 #EB1566; border: 1px solid #EB1566;">
                                    </div>

                                    <div class="box2 text-center">
                                        <img src="publics/images/logo-expresso.png" alt="" style="box-shadow: 0 1px 0 0 #22427C; border: 1px solid #22427C;">
                                    </div>

                                    <div class="box2 text-center ">
                                        <img src="publics/images/logo-pro.jpg" alt="" style="box-shadow: 0 1px 0 0 #EB1566; border: 1px solid #EB1566;">
                                    </div>

                                    <div class="box2 text-center ">
                                        <img src="publics/images/logo-atos.jpg" alt="" style="box-shadow: 0 1px 0 0 #007FFF; border: 1px solid #007FFF;">
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
    </section>

    <section oncontextmenu='return false' class="snippet-body align-items-center justify-content-center">

        <div class="container">
            <div class="row">
                <div class="col-md-1à mb-4">
                    <article class="block-wrap1">
                        <div class="col-12">
                            <div class="block-propos" data-aos="fade-down" data-aos-delay="100">
                                <div class="card-body">

                                    <p class="title-section-qsn-vc"><span class="trait-title-section-qsn-vc">Des
                                            ex</span>perts</span> à votre service</p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <div class="col-md-12">
                    <div id="news-slider" class="owl-carousel ">
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/fa.svg" alt="">

                                <div class="over-layer">
                                    <img src="publics/images/fa1.svg" alt="">
                                    <!-- <div class="row">
                                <a href="https://twitter.com/FatouMb75134996/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/fatou-mbengue-326350220/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/profile.php?id=100052115983943/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/mbengue9250/?next=%2F/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> MBENGUE </a>
                                </h3>
                                <p class="post-description">La Dynamique</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/dans.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/dans1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="https://twitter.com/DANSOKHO15/status/1477018298327916545/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/mamadou-camara-dansokho/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/mamadou.dansokho.73/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/camaradansokho/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> DANSOKHO </a>
                                </h3>
                                <p class="post-description">L'Optimiste</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/ous.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/ous1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="https://twitter.com/aw_ousseynou/" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/ousseynou-aw-2764b3b1/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/ousseynou.awlemahatma/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="https://www.instagram.com/ousseynou_aw_le_mahatma/" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">AW </a>
                                </h3>
                                <p class="post-description">Le Visionnaire</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/ch.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/ch1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/in/birahim-chim%C3%A8re-diaw/" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="https://web.facebook.com/birahimchimere/" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIAW</a>
                                </h3>
                                <p class="post-description">L'Original</p>
                            </div>
                        </div>
                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/anta.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/anta1.svg" alt="">
                                    <!-- <div class="row ">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#"> AW </a>
                                </h3>
                                <p class="post-description">La Reine</p>
                            </div>
                        </div>

                        <div class="post-slide" data-aos="flip-left" data-aos-delay="100">
                            <div class="post-img">
                                <img src="publics/images/sey.svg" alt="">
                                <div class="over-layer">
                                    <img src="publics/images/sey1.svg" alt="">
                                    <!-- <div class="row">
                                <a href="#" class="col-md-6"><i class="fab fa-twitter"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-linkedin"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-facebook"></i></a>
                                <a href="#" class="col-md-6"><i class="fa fa-square-instagram"></i></a>
                            </div> -->
                                </div>
                            </div>
                            <div class="post-content">
                                <h3 class="post-title">
                                    <a href="#">DIOUF </a>
                                </h3>
                                <p class="post-description">Le Zen</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
    </section>

    <section class="section2" id="" style="margin-top:100px; margin-bottom:100px;">

        <div class="test" style=" margin-bottom: 50px;" data-aos="zoom-in" data-aos-delay="100">
            <h3 style="margin-top: 50px;"> Newsletter</h3>
            <h5>Vous prendrez bien un petit shot d’actualité ?</h5>

            <form action="" method="post">
                <input type="text" placeholder="Enter your email ...  " id="email" name="email">

                <button type="submit" name="valider"> <img src="publics/images/envoie.png" alt=""> </button>
                <?php

                include('html/config/base.php');

                if (isset($_POST['valider'])) {
                    if (!empty($_POST['email'])) {
                        //Enregistrement à la base de données

                        $emails = $conn->query("SELECT email FROM abonnement");
                        $existe = false;
                        while ($email = $emails->fetch()) {
                            if ($_POST['email'] == $email['email']) {
                                $existe = true;
                            }
                        }

                        if ($existe) {
                            echo "<p style='text-align: center; color: red;'>Cet email existe</p>";
                        } else {
                            $sql = "INSERT INTO abonnement (email) VALUES (:email)";
                            $res = $conn->prepare($sql);
                            $insert_email = $res->execute(array(":email" => $_POST['email']));
                            // vérifier si la requête d'insertion a réussi
                            if ($insert_email) {
                                echo "<p style='text-align: center; color: green;'>L'abonnement a été envoyé avec succès.</p>";
                            } else {
                                echo "<p style='text-align: center; color: red;'>Erreur d'insertion</p>";
                            }
                        }
                    } else {
                        echo "<p style='text-align: center; color: red;'>Le champs n'est pas renseigné</p>";
                    }
                }


                ?>
                <p style="margin-top: 10px;">Retrouvez les dernières newsletters de <span>JOKKOLANTE GROUP </span> pour être incollable sur l’actualité de nos filiales et tous les projets réalisés.</p>
            </form>
        </div>

    </section>

    <?php

    include('html/footer.php');

    ?>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="publics/js/active.js"></script>
    <!-- <script src='https://code.jquery.com/jquery-1.12.0.min.js'></script> -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>
    <script type='text/javascript'>
        $(document).ready(function() {
            $("#news-slider").owlCarousel({
                items: 5,
                itemsDesktop: [1199, 5],
                itemsDesktopSmall: [980, 3],
                itemsMobile: [600, 2],
                navigation: true,
                navigationText: ["", ""],
                pagination: true,
                autoPlay: true,
                interval: 200,
                cycle: true
            });

        });
    </script>
    <script>
        $(document).ready(function() {
            $('.carousel').carousel({
                interval: 2000
            })
        });
    </script>
    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script src="publics/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="publics/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="publics/js/main.js"></script>
    <script src="publics/js/main1.js"></script>
    <script src="publics/js/menu.js"></script>
    <script>
        var
            words = ['Dalal Jàmm'],
            part,
            i = 0,
            offset = 0,
            len = words.length,
            forwards = true,
            skip_count = 0,
            skip_delay = 5,
            speed = 200;

        var wordflick = function(idH1, tab) {
            setInterval(function() {
                if (forwards) {
                    if (offset >= tab[i].length) {
                        ++skip_count;
                        if (skip_count == skip_delay) {
                            forwards = false;
                            skip_count = 0;
                        }
                    }
                } else {
                    if (offset == 0) {
                        forwards = true;
                        i++;
                        offset = 0;
                        if (i >= len) {
                            i = 0;
                        }
                    }
                }
                part = tab[i].substr(0, offset);
                if (skip_count == 0) {
                    if (forwards) {
                        offset++;
                    }
                    // else {
                    //   offset--;
                    // }
                }
                $(idH1).text(part);
            }, speed);
        };

        $(document).ready(function() {
            wordflick('#word', words);
        });
    </script>
</body>

</html>