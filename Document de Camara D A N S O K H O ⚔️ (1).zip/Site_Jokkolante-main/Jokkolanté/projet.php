<?php

include('html/config/base.php');

if (isset($_POST['valider'])) {
    $erreur = "";
    $succes = "";
    if (
        !empty($_POST['nom']) && !empty($_POST['prenom'])
        && !empty($_POST['email']) && !empty($_POST['tel'])
        && !empty($_POST['budget']) && !empty($_POST['delai'])
        && !empty($_POST['domaine']) && !empty($_POST['sujet'])
        && !empty($_POST['message'])
    ) {
        //Enregistrement à la base de données
        $sql = "INSERT INTO contact (prenom, nom, email, telephone, budget, delai, domaine, sujet, message) VALUES (:prenom, :nom, :email, :telephone, :budget, :delai, :domaine, :sujet, :message)";
        $res = $conn->prepare($sql);
        $insert_contact = $res->execute(array(":prenom" => $_POST['prenom'], ":nom" => $_POST['nom'], ":email" => $_POST['email'], ":telephone" => $_POST['tel'], ":budget" => $_POST['budget'], ":delai" => $_POST['delai'], ":domaine" => $_POST['domaine'], ":sujet" => $_POST['sujet'], ":message" => $_POST['message']));
        // vérifier si la requête d'insertion a réussi
        if ($insert_contact) {


            //Envoie de mail
            // $from =  $_POST['email'];
            // $to = "dramembasa2000@gmail.com";
            // $sujet = $_POST['sujet'];
            // $message = "Prénom : " .$_POST['prenom']."\r\nNom : " .$_POST['nom']."\r\nEmail : " .$_POST['email']."\r\nTéléphone : " .$_POST['tel']."\r\nBudget : " .$_POST['budget']."\r\nDelai : " .$_POST['delai']."\r\nDomaine d'activité : " .$_POST['domaine']."\r\n";
            // $message .=  "Message : ".$_POST['message'];
            // $headers = "Content-Type: text/plain; charset=utf-8\r\nDe: " .$from;
            // // $headers .= "Reply To: " .$from."\r\n";

            // if (mail($to, $sujet, $message, $headers)) {
            $succes = "Le Message a été envoyé avec succès.";
            // } else {
            //     $erreur = "Erreur survenu";
            // }

        }
    } else {
        $erreur = "Tous les champs ne sont pas renseignés";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title> Projet </title>

    <link rel="icon" type="image/x-icon" href="publics/images/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="http://daneden.me/animate">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@700&family=Ubuntu&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->

    <link href="publics/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>
    <link rel="stylesheet" href="publics/css/header.css">
    <link rel="stylesheet" href="publics/css/footer.css">
    <link rel="stylesheet" href="publics/css/bande.css">
    <link rel="stylesheet" href="publics/css/projet.css">
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(function() {
                var dropdownMenu = $(this).children(".dropdown-menu");
                if (dropdownMenu.is(":visible")) {
                    dropdownMenu.parent().toggleClass("open");
                }
            });
        });
    </script>
</head>

<body>


    <?php
    include "html/header.php";
    ?>

    <section id="contact" class="contact-form section-bg" data-aos="fade-down" data-aos-delay="100">
        <div class="container">
            <div class="row justify-content-center" style=" width: 100%; ">
                <h2>Donnez les informations de votre projet</h2>
                <div class="col-lg-9 mt-4 mt-lg-0" style="background-color: #fff; padding: 20px 20px 20px 20px; border-radius: 5px;box-shadow: 0 0 30px rgba(214, 215, 216, 0.6);;width:100%; margin-left: 20px;">
                    <form action="" method="POST" id="projetForm" class="projetForm">
                        <div class="row">

                            <div class="col-md-3 form-group mt-3 mt-md-0">
                                <input type="text" name="nom" class="form-control" id="nom" placeholder="Nom">
                            </div>
                            <div class="col-md-3 form-group mt-3 mt-md-0">
                                <input type="text" class="form-control" name="prenom" id="prenom" placeholder="Prénom">
                            </div>
                            <div class="col-md-3 form-group mt-3 mt-md-0">
                                <input type="text" class="form-control" name="email" id="email" placeholder="Email">
                            </div>
                            <div class="col-md-3 form-group mt-3 mt-md-0">
                                <input type="text" name="tel" class="form-control" id="tel" placeholder="Téléphone">
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-md-6 form-group mt-3 mt-md-0">
                                <input type="text" class="form-control" name="budget" id="budget" placeholder="Budget">
                            </div>
                            <div class="col-md-6 form-group mt-3 mt-md-0">
                                <input type="text" class="form-control" name="delai" id="delai" placeholder="Delai">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 form-group mt-3 mt-md-0">
                                <input type="text" class="form-control" name="sujet" id="sujet" placeholder="Sujet">
                            </div>
                            <div class="col-md-6 form-group mt-3 mt-md-0">
                                <select name="domaine" class="form-control" style="color: #EB1566;">
                                    <option value="Création Graphique" selected>Création Graphique</option>
                                    <option value="Développement Web">Développement Web</option>
                                    <option value="Communication Digitale">Communication Digitale</option>
                                    <option value="Production Audiovisuelle">Production Audiovisuelle</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group mt-3 mt-md-0">
                            <textarea class="form-control" style="height:80px;" name="message" rows="5" placeholder="Message"></textarea>
                        </div>
                        <div class="my-3 text-center">
                            <span id="succes" style="color: green;"><?php if (isset($succes)) {
                                                                        echo $succes;
                                                                    } ?></span>
                            <span id="error" style="color: red;"><?php if (isset($erreur)) {
                                                                        echo $erreur;
                                                                    } ?></span>
                        </div>
                        <div class="text-center">
                            <input type="submit" value="Envoyer" name="valider" style="height: 40px; width: 100px; font-family: 'ubuntu';font-style: normal;background-color: #EB1566; color:#fff; border: none; border-radius: 5px;">
                        </div>
                    </form>
                </div>
            </div>

    </section>




    <?php

    include('html/footer.php');

    ?>

    <script src="../../publics/js/projet.js"></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="publics/js/active.js"></script>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js'></script>

    <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js'></script>
    <script src="publics/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="publics/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="publics/js/main.js"></script>
    <script src="publics/js/main1.js"></script>
    <script src="publics/js/menu.js"></script>
</body>
</body>

</html>