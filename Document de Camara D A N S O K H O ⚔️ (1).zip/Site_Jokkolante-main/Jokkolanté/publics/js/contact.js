
const contactForm = _('contactForm');

function _(e) {
    return document.getElementById(e);
}



//
contactForm.addEventListener('submit', function (e) {

    // Recupérer les inputs 
    let nom = _('nom');
    let email = _('email');
    let sujet = _('sujet');
    let message = _('message');

    // Vérification des inputs d'entrées 
    if (nom.value.trim() == "" || email.value.trim() == "" || sujet.value.trim() == "" || message.value.trim() == "") {
        let error = _('error');
        error.innerHTML = 'Les champs sont requis';
        error.style.color = 'red';
        e.preventDefault();
    }
});