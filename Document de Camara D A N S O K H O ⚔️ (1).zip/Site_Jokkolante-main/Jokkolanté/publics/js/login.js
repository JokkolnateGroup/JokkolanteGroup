const loginForm = _('loginForm');

    function _(e) {
      return document.getElementById(e);
    }
    //
    loginForm.addEventListener('submit', function(e) {

      // Recupérer les inputs 
      let nom = _('pseudo');
      let email = _('mdp');

      // Vérification des inputs d'entrées 
      if (nom.value.trim() == "" || email.value.trim() == "") {
        let error = _('error');
        error.innerHTML = 'Les champs sont requis';
        error.style.color = 'red';
        e.preventDefault();
      }
    });