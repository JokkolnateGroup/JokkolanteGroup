let toggle = document.querySelector('.toggle');
let body = document.querySelector('header');

toggle.addEventListener('click', function() {
    body.classList.toggle('open');
});