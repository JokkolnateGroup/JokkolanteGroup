const lang = document.querySelector('.lang');
const list = document.querySelector(".list");
const select = document.querySelector('.select');
const selectImg = document.querySelector('.selectImg');

lang.addEventListener('click', ()=>{
    list.classList.toggle('show');
})

list.addEventListener('click', (e)=>{
    const img = e.target.querySelector('img');
    const text = e.target.querySelector('.text');
    selectImg.src = img.src;
    select.innerHTML = text.innerHTML;
})